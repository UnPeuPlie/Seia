#Langue
**Le Commun** est la langue universelle de Seia, née du besoin de communication entre peuples d’horizons divers. Son origine remonte aux premiers grands échanges commerciaux et aux alliances entre royaumes humains : au fil des siècles, un idiome simple et adaptable s’est imposé pour que marchands, diplomates et voyageurs puissent se comprendre par-delà les frontières. On raconte que jadis un vaste empire humain encouragea l’usage d’une **langue commune** pour unifier ses sujets – ce qui accéléra sa diffusion à travers le continent. Qu’il soit né dans les ports cosmopolites ou le long des routes caravanières, le Commun a prospéré grâce à son utilité et à sa souplesse, jusqu’à devenir la lingua franca de pratiquement toutes les contrées civilisées.

Aujourd’hui, le Commun est parlé ou au moins compris par la majorité des habitants de Seia. Les humains l’emploient comme langue maternelle dans la plupart de leurs cités, et de nombreuses autres races l’apprennent en seconde langue par pure nécessité. C’est le langage du **commerce**, utilisé aussi bien dans les bazars animés des cités marchandes que sur les chemins où se croisent voyageurs de toutes origines. En **diplomatie**, il sert de terrain neutre : autour d’une table de négociation, il n’est pas rare de voir des seigneurs elfes, nains et humains converser en Commun pour s’assurer que chacun est compris de tous. Même certains orques ou gobelins, s’ils traitent fréquemment avec l’extérieur, finissent par baragouiner quelques phrases de Commun pour troquer ou parlementer.

La simplicité du Commun fait partie de sa force. Son système d’écriture phonétique, inspiré en partie des runes naines mais arrondi et adapté au parchemin, est facile à apprendre et largement répandu. Des écoles dans presque chaque bourg enseignent **l’alphabet du Commun** aux enfants, car savoir lire et écrire cette langue ouvre les portes du commerce, de l’administration et du savoir partagé. Oralement, le Commun est direct et moins orné que d’autres langues plus anciennes : sa prononciation évite les sons trop gutturaux ou trop chantants, si bien qu’un elfe à la voix cristalline, un nain à l’accent rocailleux ou même un orque à la gorge grondante peuvent tous le parler sans trop de peine. Souple et en constant enrichissement, il incorpore volontiers des emprunts d’autres langues lorsqu’il découvre de nouveaux objets, idées ou besoins d’expression – c’est ainsi qu’au fil du temps, le Commun est devenu un véritable patchwork reflétant la diversité de Seia.

Langue commune par excellence, le Commun n’est ni rare ni ésotérique – au contraire, il fait partie de la vie quotidienne de la plupart des habitants. Sa facilité d’apprentissage et son utilité en ont fait un dénominateur culturel commun : un fermier humain peut échanger quelques mots avec un marchand nain itinérant grâce à quelques phrases de Commun partagées, là où aucun des deux ne parlerait la langue natale de l’autre. Bien qu’il manque peut-être de la richesse poétique de l’Elfique ou de la solennité de l’Ancien, le Commun porte en lui un peu de chaque culture de Seia. On y trouve des tournures idiomatiques venues de dizaines de peuples différents, reflet du métissage linguistique qui caractérise les grandes villes cosmopolites. Ce rôle utilitaire en fait parfois la cible d’une certaine condescendance de la part des peuples plus anciens (les Elfes le jugent terre-à-terre et banal, les Nains le trouvent trop volubile et imprécis dans certains domaines techniques). Néanmoins, personne ne peut nier que sans le Commun, les échanges, alliances et découvertes qui façonnent le monde seraient bien plus ardus. C’est la langue de l’entente et de la coopération, un fil conducteur entre des nations et des races aux langues natales différentes.

## ✦ Alphabet du **Commun**

→ _Fonctionnel, droit, inspiré des runes simplifiées. Pensé pour l’efficacité._

| Lettre | Son |
| ------ | --- |
| Ael    | A   |
| Ber    | B   |
| Kal    | C   |
| Del    | D   |
| Eni    | E   |
| Fin    | F   |
| Gal    | G   |
| Har    | H   |
| Is     | I   |
| Jal    | J   |
| Kon    | K   |
| Lun    | L   |
| Min    | M   |
| Niv    | N   |
| Or     | O   |
| Paen   | P   |
| Qua    | Q   |
| Rah    | R   |
| Sin    | S   |
| Tor    | T   |
| Ul     | U   |
| Vek    | V   |
| Wer    | W   |
| Xir    | X   |
| Yon    | Y   |
| Zan    | Z   |

🖋️ _Style :_ lettres carrées, simples à graver ou tracer sur parchemin. Calligraphie lisible.

## ✦ Nombres en **Commun**

→ _Système décimal standardisé. Identique de l’usage humain classique._

🖋️ _Lisibles et pratiques, ces chiffres sont standardisés pour le commerce et les échanges diplomatiques._