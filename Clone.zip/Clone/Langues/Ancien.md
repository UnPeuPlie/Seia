#Langue
**L’Ancien**, parfois nommé **Langue Ancienne** ou **Vieille Parole**, plane sur Seia tel un écho du passé lointain. Son origine exacte se perd dans la nuit des temps. D’aucuns prétendent qu’il s’agissait de la langue primordiale enseignée par les dieux aux premiers habitants du monde, lorsque la magie elle-même venait d’éclore. D’autres avancent qu’un antique empire, humain ou céleste, l’aurait utilisée pour administrer ses vastes domaines et consigner son savoir, avant que sa chute n’entraîne l’oubli de cet idiome autrefois universel. Quoi qu’il en soit, l’Ancien est sans conteste la plus vieille langue connue de Seia, et aussi la plus mystérieuse : depuis des millénaires, **plus aucun peuple ne la parle couramment** au quotidien, et elle a laissé sa place aux langues plus jeunes.

De nos jours, nul groupe mortel n’a l’Ancien pour langue maternelle – il s’agit d’une **langue morte**, préservée seulement dans les écrits sacrés et la mémoire des érudits. Pourtant, elle n’est pas totalement éteinte. Les sages des grandes bibliothèques, les archimages des tours d’ivoire et certains prêtres des cultes les plus anciens s’astreignent à apprendre l’Ancien afin de percer les secrets des archives du monde. C’est la langue des inscriptions gravées sur les monolithes rongés par le lichen, des parchemins fragiles trouvés dans des tombeaux scellés, et des prophéties obscures que l’on peine à traduire. Quelques **créatures immortelles** ou quasi immortelles sont également susceptibles de parler l’Ancien. On raconte par exemple que les plus vieux dragons, témoins de l’aube des âges, connaissent cette langue et l’emploient parfois entre eux ou pour communiquer avec des êtres primordiaux. De même, certains esprits éternels, fées originelles des premiers bois ou even un roi-liche enfermé dans sa nécropole, peuvent encore articuler les syllabes de l’Ancien dans un murmure glacé, eux qui ont traversé les siècles.

L’Ancien est avant tout la **langue du savoir oublié et de la magie profonde**. Maîtriser l’Ancien, pour un érudit, c’est détenir la clé de connaissances oubliées : les chroniques les plus anciennes du monde, les traités de magie primordiale ou les légendes de la création de Seia sont souvent rédigés dans cette langue. Les mages étudient donc au moins les rudiments de l’Ancien pour pouvoir déchiffrer un grimoire antique ou comprendre le vrai nom d’une créature surnaturelle – car dans la tradition arcanique, connaître le nom originel d’une chose donne du pouvoir sur elle. En outre, nombre de rituels de haute magie incluent des incantations en Ancien, jugées plus efficaces ou plus solennelles. Par exemple, un sort de bannissement d’un démon majeur sera souvent récité en partie en Ancien au sein d’un cercle de magiciens, afin d’invoquer l’autorité des premiers pactes divins gravés dans cette langue. De même, certains **cultes** vénérant de très anciennes divinités conservent des prières en Ancien, persuadés que ces mots d’antan portent une force sacrée que les langues modernes ont diluée au fil du temps. Ainsi, la langue ancienne subsiste dans les temples oubliés et les cérémonies ésotériques, chaque mot prononcé faisant vibrer une corde mystique reliée aux origines du monde.

Écrire l’Ancien relève de l’art ésotérique. Son système d’écriture, complexe et archaïque, diffère des alphabets simples comme celui du Commun. Il se présente souvent sous forme de signes **élaborés et archaïques**, mêlant idéogrammes, syllabes et symboles abstraits. Sur les fresques murales d’un temple en ruine, on peut voir de longues colonnes de caractères serrés les uns contre les autres, entremêlant des éléments qui évoquent à la fois des constellations, des spirales et des glyphes magiques. Déchiffrer ces textes nécessite un apprentissage long et rigoureux – c’est un véritable casse-tête pour les linguistes de Seia. Quelques sages dévoués ont consacré leur vie à compiler des lexiques de l’Ancien, comparant les inscriptions découvertes aux quatre coins du monde pour reconstituer patiemment son vocabulaire et sa grammaire. Hélas, il manque toujours des pièces au puzzle, et certaines tablettes couvertes de script ancien défient encore toute traduction, gardant jalousement leurs secrets jusqu’à ce que le contexte approprié ou un sortilège de compréhension vienne les révéler.

Sur le plan **oral**, l’Ancien n’est presque jamais entendu dans une conversation ordinaire. Sa prononciation exacte fait d’ailleurs débat : faute de locuteurs natifs depuis des siècles, ce sont les érudits qui ont tenté de reconstruire la manière dont s’exprimaient jadis les Anciens. Il en résulte une langue parlée solennelle et sonore, aux mots longs et aux sonorités pleines. La récitation d’un texte en Ancien a quelque chose de rituel : le rythme en est lent et mesuré, chaque terme pesé comme un serment ancien. Certains sons de l’Ancien n’ont pas d’équivalent direct dans les langues modernes, si bien que les apprentis conjurateurs butent souvent sur des phonèmes étranges en tentant de lire à voix haute un passage ésotérique. Malgré ces difficultés, lorsque l’Ancien est psalmodié correctement au cours d’une cérémonie magique, on dit qu’il fait vibrer l’air d’une énergie singulière. De nombreux témoins assurent que le simple fait d’entendre quelques phrases prononcées en Ancien – sans même en saisir le sens – suffit à inspirer crainte et révérence, comme si la voix d’un âge révolu traversait le présent.

Dans la vie courante à Seia, l’Ancien n’apparaît qu’en filigrane. Un paysan ou un artisan n’en connaîtra généralement pas une seule expression, hormis peut-être ce qu’il a entendu dans une légende ou déchiffré sans le comprendre sur un vieux monument du village. Pour la plupart des gens, l’Ancien évoque donc avant tout une aura de mystère et de respect lointain : c’est la langue des sages, des sortilèges et des mythes, pas celle du marché ni de la chancellerie. Son **prestige intellectuel** est toutefois indéniable. Les académies la considèrent comme une langue classique incontournable pour qui poursuit des études historiques ou magiques poussées. À l’Université d’Arcanel, par exemple, on exige des élèves avancés qu’ils déchiffrent et traduisent des passages de textes en Ancien pour obtenir leur maîtrise en arcanes. De même, dans certaines cours royales, connaître une devise en Ancien ou citer une maxime d’un philosophe antique au détour d’un discours peut impressionner l’auditoire et conférer un vernis de sagesse à celui qui parle. Pour autant, l’Ancien reste essentiellement le domaine des **initiés**. C’est une langue qui vit dans les bibliothèques, les temples et les laboratoires d’alchimistes bien plus que dans les rues ou sur les champs de bataille. Elle symbolise la continuité entre le présent et les âges mythiques : chaque fois qu’un érudit prononce un mot en Ancien, il réveille un fragment de l’histoire de Seia. Tant que cette langue résonnera, fut-ce à travers la voix d’un seul mage ou d’un seul esprit, le souvenir des premiers temps du monde perdurera, et avec lui la sagesse et les mystères des ancêtres.

## ✦ Alphabet de l’**Ancien**

→ _Système idéographique et symbolique. Chaque lettre est un glyphe riche de sens._

| Son   | Lettre | Glyphe                               |
| ----- | ------ | ------------------------------------ |
| Aet   | A      | ![[Pasted image 20250523115503.png]] |
| Bel   | B      | ![[Pasted image 20250523115522.png]] |
| Cel   | C/K    | ![[Pasted image 20250523115535.png]] |
| Der   | D      | ![[Pasted image 20250523115546.png]] |
| Enu   | E      | ![[Pasted image 20250523115600.png]] |
| Fal   | F      | ![[Pasted image 20250523115613.png]] |
| Ghar  | G      | ![[Pasted image 20250523115624.png]] |
| Hir   | H      | ![[Pasted image 20250523115635.png]] |
| Inil  | I      | ![[Pasted image 20250523115651.png]] |
| Jehn  | J      | ![[Pasted image 20250523115703.png]] |
| Kol   | K      | ![[Pasted image 20250523115724.png]] |
| Lem   | L      | ![[Pasted image 20250523115742.png]] |
| Menor | M      | ![[Pasted image 20250523115755.png]] |
| Nem   | N      | ![[Pasted image 20250523115805.png]] |
| Oran  | O      | ![[Pasted image 20250523115820.png]] |
| Pal   | P      | ![[Pasted image 20250523115832.png]] |
| Quel  | Q      | ![[Pasted image 20250523115842.png]] |
| Rahn  | R      | ![[Pasted image 20250523115910.png]] |
| Sen   | S      | ![[Pasted image 20250523115930.png]] |
| Tar   | T      | ![[Pasted image 20250523125802.png]] |
| Ulom  | U      | ![[Pasted image 20250523125811.png]] |
| Vel   | V      | ![[Pasted image 20250523125823.png]] |
| Weron | W      | ![[Pasted image 20250523125832.png]] |
| Xar   | X      | ![[Pasted image 20250523125846.png]] |
| Yul   | Y      | ![[Pasted image 20250523125855.png]] |
| Zor   | Z      | ![[Pasted image 20250523125907.png]] |

## ✦ Nombres en **Ancien**

→ _Idéogrammes mystiques, chaque chiffre incarne un concept cosmique._

| Son    | Chiffre | Glyphe Ancien                        | Signification Ésotérique      |
| :----- | ------- | ------------------------------------ | ----------------------------- |
| Zhal   | 0       | ![[Pasted image 20250523125930.png]] | Le Vide – commencement absolu |
| Orun   | 1       | ![[Pasted image 20250523130014.png]] | L’Œil – conscience            |
| Delvak | 2       | ![[Pasted image 20250523130025.png]] | La Dualité                    |
| Triax  | 3       | ![[Pasted image 20250523130036.png]] | L’Équilibre                   |
| Kareth | 4       | ![[Pasted image 20250523130048.png]] | La Matière                    |
| Sulen  | 5       | ![[Pasted image 20250523130057.png]] | Le Cycle                      |
| Vadril | 6       | ![[Pasted image 20250523130106.png]] | Le Savoir                     |
| Ezkor  | 7       | ![[Pasted image 20250523130116.png]] | L’Épreuve                     |
| Lumeth | 8       | ![[Pasted image 20250523130125.png]] | Le Souffle                    |
| Tharon | 9       | ![[Pasted image 20250523130135.png]] | L’Ascension                   |

📜 _Les nombres en Ancien ne sont pas seulement utilisés pour compter. Ils sont intégrés dans des glyphes rituels et souvent associés à des mots-clés magiques. Un nombre mal écrit peut altérer un sort._