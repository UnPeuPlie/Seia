### ☂ Rôle dans l’Église

Les **Gouttelots** sont les enfants et les jeunes recueillis par l’Église — parfois orphelins, fugitifs ou simplement oubliés.  
Ils ne sont pas formés, ils sont **accompagnés**.  
Ils représentent l’avenir de l’Église, non pas en tant qu’héritiers, mais en tant que **formes pures du geste silencieux**.

Ils sont **écoute, imitation, fragilité acceptée.**

---

### ☂ Attributions

- Observer les rites et gestes sans explication
    
- Participer aux soins, nettoyages, veillées
    
- Accompagner les Mains ou Boucliers en mission d’écoute
    
- Recevoir la mémoire par le corps avant de la comprendre par la parole
    
- Devenir un miroir vivant de la doctrine par leurs actes simples
    

---

### ☂ Apparence

- Tunique simple en lin, parfois usée, souvent retouchée
    
- Pas de couleur imposée, mais des tons naturels (argile, brume, mousse)
    
- Chaque Gouttelot porte un petit objet personnel autour du cou, attaché par un fil (pierre, perle d’os, feuille, anneau d’argile)
    
- Regard souvent intense, curieux, sans jugement
    

---

### ☂ Formation

- Aucun enseignement structuré
    
- Les Gouttelots **imprègnent la mémoire des lieux**, des gestes et des silences
    
- À 7 ans : **Rite du Premier Silence**
    
- À 12 ans : **Rite du Choix**, devant la **Pierre du Cercle**, avec une goutte d’argile façonnée par leurs soins
    

---

### ☂ Paroles usuelles

- _« Pourquoi tu cries ? Je suis là. »_
    
- _« Je fais comme toi. Mais un peu plus doucement. »_
    
- _« C’est la pluie qui m’a réveillé. Je savais que je devais venir. »_
    

---

### ☂ Rites propres

- **Premier Silence** : une nuit seul avec une bougie et de l’eau
    
- **Dessin de Goutte** : tracer un glyphe dans l’eau, gardé par le Mur
    
- **Tissage Miroir** : entrelacer une corde à côté d’une Main pendant une mission silencieuse
    

---

### ☂ Progression

- À l’issue du Rite du Choix, le Gouttelot peut devenir :
    
    - **Main**
        
    - **Bouclier** (plus tard, s’il en prend la voie)
        
    - ou **partir** (certains gardent la pluie en eux, mais sans rejoindre l’ordre)
        

---

### ☂ Citation rituelle

> _« Les Gouttelots ne parlent pas fort. Mais quand ils tendent la main, la pluie répond. »_