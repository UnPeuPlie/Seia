#Religion
![[ChatGPT Image May 26, 2025, 01_22_58 PM.png]]
## 📖 _Livre des Ondes — Chapitre Premier_

### L'Église de la Pluie Éternelle

> _« Comme la pluie nourrit la terre sans attendre le remerciement, ainsi devons-nous guider ceux qui ne voient pas encore la lumière. »_

---

### ✦ Origine

Née des Premiers Marcheurs qui traversèrent les terres sèches après la Chute des Échos, l’Église de la Pluie Éternelle fut fondée autour d’un principe simple : **nul ne devrait marcher seul, et nul ne devrait oublier qui lui tendit la main.** Ceux qui ont appris doivent enseigner. Ceux qui ont été protégés doivent protéger.

On dit que la toute première pluie qui tomba sur Seia après les jours cendrés fut accueillie par des chants silencieux et des gestes de gratitude. Ce fut le premier sermon, transmis non par la parole, mais par la reconnaissance partagée.

---

### ✦ Doctrine sacrée

> _« Celui qui t’élève t’offre la mémoire. Celui que tu élèves t’offre la justice. »_

L’Église prône :

- La **reconnaissance** envers ceux qui ont guidé.
    
- L’**aide active** envers les plus faibles ou inexpérimentés.
    
- La **transmission des savoirs** sans orgueil.
    
- Le **refus du mépris** envers les ignorants.
    
- L’**équilibre dans le don et la réception**.
    

La force n’est pas une supériorité, mais une responsabilité.

---

### ✦ Hiérarchie

Chaque membre de l’Église est à la fois un guide et un élève. Les titres ne sont pas une couronne, mais un manteau qu’on porte pour protéger autrui.

|Rang|Rôle symbolique|
|---|---|
|**Héraut**|Porte la Voix de la Pluie, guide l’ensemble de l’ordre. Seul à parler dans les Silences Célestes.|
|**Mur**|Soutient, défend, transmet. Il est la force tranquille, le protecteur des faibles et l’écoute des errants.|
|**Bouclier**|Intervient, protège activement, corrige les abus. Il est le bras qui agit quand la Parole ne suffit plus.|
|**Main**|Le plus humble. Sert, apprend, accompagne. Porte les fardeaux du monde sans juger.|

> _« Le Héraut éclaire. Le Mur soutient. Le Bouclier encaisse. La Main tend. »_

---

### ✦ Rituel d’entrée

Tout nouveau fidèle subit la **Veillée des Premiers Pas** :

- Il se tient nu sous la pluie, les bras ouverts.
    
- Il ne peut parler ni demander.
    
- Un membre de l’ordre vient alors le couvrir.
    
- Ce geste seul fait de lui un initié.
    

Car **ceux qui aident sans qu’on le leur demande** incarnent l’esprit de l’Église.

---

### ✦ Signe sacré

Le symbole de l’Église est :

- Une **main ouverte** tournée vers le ciel,
    
- **Trois gouttes** tombant dessus,
    
- Entourées d’un **cercle de brume.
    

On le porte souvent en broche, gravé sur le torse, ou cousu sur une épaule gauche.

---

### ✦ Prières fondamentales

**Prière du Don**

> _« Puisque l’on m’a guidé, je guiderai.  
> Puisqu’on m’a tendu la main, je ne la refermerai jamais.  
> Pluie du ciel, que ma force serve aux autres. »_

**Litanie de la Reconnaissance**

> _« À ceux qui m’ont élevé, je donne mes pas.  
> À ceux qui me suivent, je donne mon ombre.  
> Et si je tombe, que la pluie m’efface doucement. »_