#Langue
**L’Elfique** est sans doute la plus ancienne des langues encore parlées couramment en Seia, un idiome dont les racines remontent à l’aube du monde. Les légendes elfiques content que leurs premiers ancêtres, éveillés sous la voûte étoilée, apprirent la parole en écoutant le chant du vent et des astres. De ce fait, l’Elfique a toujours été bien plus qu’un simple outil de communication pour les Elfes : c’est une composante sacrée de leur héritage, transmise immuablement de génération en génération quasi-immortelle. Au fil des millénaires, la langue a peu évolué – un elfe contemporain peut sans grande difficulté lire les poèmes gravés par ses aïeux il y a des siècles, tant sa structure et son vocabulaire ont été jalousement préservés.

Parlée par l’ensemble des peuples elfes, qu’ils vivent dans d’élégantes cités de marbre blanc ou au cœur des forêts anciennes, l’Elfique forme un lien culturel puissant unissant tous les Elfes de Seia. S’il existe de légères variations dialectales d’une enclave elfique à l’autre (un accent différent chez les Elfes sylvains des bois profonds par rapport aux Hauts Elfes des hautes terres, par exemple), ces différences n’empêchent en rien la compréhension mutuelle. Un Elfe des montagnes pourra sans peine converser avec un Elfe des bois, chacun reconnaissant dans la parole de l’autre la même langue chantante apprise des Anciens. **Hors des communautés elfes, cette langue est beaucoup plus rare** : seuls quelques érudits humains, bardes curieux ou diplomates proches des cours féeriques apprennent l’Elfique par passion ou par nécessité. Pour un non-Elfe, maîtriser cette langue est un signe d’érudition – et souvent une marque de respect envers le peuple immortel. Entendre un humain s’exprimer correctement en Elfique, ne serait-ce que pour saluer ou déclamer un proverbe, est pour les Elfes un gage de considération qui peut grandement lisser les interactions.

L’Elfique est indissociable du **contexte magique et artistique** de Seia. De nombreux anciens grimoires et traités d’arcane sont rédigés en Elfique, reflet du rôle central qu’a joué le peuple elfique dans l’histoire mystique du monde. Les chants enchantés, les poèmes mythiques, les prières aux esprits de la nature et les chroniques historiques des grands royaumes elfes ont été consignés dans cette langue mélodieuse. Encore aujourd’hui, un sortilège murmuré en Elfique semble porter une élégance et une puissance particulières, comme si chaque mot était imprégné du long savoir des premiers mages sylvains. De même, dans la vie quotidienne des Elfes, l’Elfique sert aux conversations intimes, aux conseils des sages et aux cérémonies traditionnelles – jamais un Elfe ne s’exprimera en Commun pour évoquer des sujets qui touchent à son cœur ou à ses croyances profondes. Leur langue est le vecteur naturel de leurs émotions et de leur pensée, et beaucoup d’Elfes considèrent que les autres idiomes sonnent maladroits ou abrupts lorsqu’il s’agit de décrire la beauté d’une forêt au crépuscule ou la tristesse d’un adieu.

Le système d’écriture elfique est à l’image de la langue elle-même : **gracieux et complexe**. L’alphabet elfique se compose de caractères élégants aux courbes harmonieuses, souvent comparés à des entrelacs de lianes ou à des motifs d’étoiles stylisés. Autrefois, les Elfes gravaient leurs mots sacrés dans l’écorce des arbres ou sur des obélisques de pierre moussue, pensant que la nature garderait ainsi trace de leur savoir pour l’éternité. Sur parchemin, leur calligraphie est réputée pour sa beauté raffinée : chaque lettre semble se fondre dans la suivante en une arabesque continue, qualité idéale pour la poésie et le chant.

Oralement, l’Elfique se distingue par sa **musicalité exceptionnelle**. C’est une langue chantante, aux sonorités fluides et aux voyelles longues et mélodieuses. Un simple salut elfique peut avoir des intonations dignes d’un vers de chanson, et nombre d’étrangers restent émerveillés en écoutant une berceuse elfique sans même en comprendre les paroles. Cette finesse a toutefois son revers – la langue exige une prononciation précise et un sens aigu de l’intonation, ce qui la rend ardue à maîtriser pour qui n’y a pas été bercé dès l’enfance. Les consonnes subtiles et les nuances de ton peuvent facilement échapper aux non-initiés, si bien que **parler Elfique couramment** est un véritable exploit pour un humain. Il n’est pas rare qu’un accent étranger, si léger soit-il, trahisse immédiatement l’orateur non-elfe aux oreilles avisées d’un Elfe.

Dans la culture de Seia, l’Elfique occupe une place prestigieuse bien que minoritaire. Les œuvres littéraires elfiques – poèmes épiques, récits mythologiques, traités de philosophie – sont célébrées pour leur profondeur et leur style, et beaucoup circulent sous forme de traductions en Commun qui n’en restituent qu’imparfaitement la beauté originelle. Lors des interactions diplomatiques, un ambassadeur humain qui adresse quelques mots en Elfique au monarque des Elfes témoigne d’une grande politesse, car cet effort honore la culture de son hôte. Inversement, les Elfes, fiers de leur langage, emploient rarement l’Elfique hors de leurs terres sauf pour marquer un moment solennel ou privé – par exemple, un chant funèbre lors des funérailles d’un dignitaire elfe même si des alliés étrangers y assistent. Ils protègent jalousement leur langue comme un trésor, conscients que chaque idiome porte une vision du monde : l’Elfique, avec sa longévité, sa poésie et son harmonie, reflète la perspective quasi éternelle et l’âme artistique de ceux qui le parlent.

## ✦ Alphabet **Elfique**

→ _Linéaire, calligraphique, très fluide, inspiré des formes naturelles et musicales._

| Son  | Lettre | Glyphe                               |
| ---- | ------ | ------------------------------------ |
| Ae   | a/æ    | ![[Pasted image 20250523110847.png]] |
| Ben  | b      | ![[Pasted image 20250523110903.png]] |
| ca   | c      | ![[Pasted image 20250523110919.png]] |
| Dae  | d      | ![[Pasted image 20250523110942.png]] |
| El   | e      | ![[Pasted image 20250523110954.png]] |
| Fir  | f/ph   | ![[Pasted image 20250523111009.png]] |
| Gae  | g      | ![[Pasted image 20250523111029.png]] |
| Hae  | h      | ![[Pasted image 20250523111039.png]] |
| Il   | i      | ![[Pasted image 20250523111057.png]] |
| Jai  | j      | ![[Pasted image 20250523111112.png]] |
| Kal  | k      | ![[Pasted image 20250523111154.png]] |
| Lal  | l      | ![[Pasted image 20250523111238.png]] |
| Men  | m      | ![[Pasted image 20250523111248.png]] |
| Nen  | n      | ![[Pasted image 20250523111257.png]] |
| On   | o      | ![[Pasted image 20250523111314.png]] |
| Pha  | p      | ![[Pasted image 20250523111326.png]] |
| Quel | q      | ![[Pasted image 20250523111337.png]] |
| Rin  | r      | ![[Pasted image 20250523111349.png]] |
| Sil  | s      | ![[Pasted image 20250523111404.png]] |
| Tem  | t      | ![[Pasted image 20250523111459.png]] |
| Ul   | u      | ![[Pasted image 20250523111534.png]] |
| Vaen | v      | ![[Pasted image 20250523111547.png]] |
| Wae  | w      | ![[Pasted image 20250523111518.png]] |
| Xae  | x      | ![[Pasted image 20250523111510.png]] |
| Yai  | y      | ![[Pasted image 20250523112157.png]] |
| Zil  | z      | ![[Pasted image 20250523111449.png]] |

## ✦ Nombres en **Elfique**

→ _Système numérique fluide, inspiré des cycles lunaires et célestes._

| Son      | Chiffre | Glyphe Elfique                       |
| -------- | ------- | ------------------------------------ |
| Nyel     | 0       | ![[Pasted image 20250523112246.png]] |
| Aelin    | 1       | ![[Pasted image 20250523112301.png]] |
| Delar    | 2       | ![[Pasted image 20250523112313.png]] |
| Triniel  | 3       | ![[Pasted image 20250523112325.png]] |
| Carnaë   | 4       | ![[Pasted image 20250523112336.png]] |
| Eruil    | 5       | ![[Pasted image 20250523112348.png]] |
| Silvaran | 6       | ![[Pasted image 20250523112358.png]] |
| Vaenil   | 7       | ![[Pasted image 20250523112408.png]] |
| Lomaeth  | 8       | ![[Pasted image 20250523112418.png]] |
| Thalanor | 9       | ![[Pasted image 20250523112430.png]] |

🌙 _Les Elfes privilégient la poésie même dans les chiffres. Ces formes sont souvent calligraphiées sur les parchemins célestes et les horloges d’observation stellaire._