#Langue
**Le Nain**, langue des fils de la montagne, est un parler aussi ancien et solide que la roche dont les Nains tirent leur substance. Selon les mythes de ce peuple, c’est le Grand Forgeron des origines – leur divinité créatrice – qui grava les premiers mots dans la pierre et les enseigna aux patriarches nains. Ainsi, lorsque les premiers Nains émergèrent des entrailles de la terre, ils connaissaient déjà les chants et les noms de leur langue sacrée, taillés dans la pierre même de leur être. Depuis ces temps immémoriaux, le Nain a très peu changé : des artisans barbus travaillant aujourd’hui dans une forge souterraine peuvent encore comprendre sans peine les inscriptions millénaires laissées par leurs aïeux sur les murs des anciennes citadelles. Des forteresses du Grand Nord aux mines des chaînes montagneuses du Sud, tous les clans nains partagent cette langue ancestrale, preuve de l’unité culturelle de leur peuple à travers les distances et les âges.

La langue naine est parlée avant tout par le peuple nain lui-même, au sein de leurs royaumes souterrains et de leurs guildes d’artisans. Les Nains étant relativement isolationnistes, il est rare d’entendre du Nain en dehors de leurs vastes halls de pierre – excepté lorsque des émissaires ou des marchands nains discutent discrètement entre eux dans une ville humaine. Les autres races maîtrisent très peu ce langage : un étranger connaîtra tout au plus quelques mots isolés, aperçus sur une hache ouvragée ou appris au cours d’échanges commerciaux. **Apprendre le Nain** dans son entier est une entreprise ardue pour un non-natif, non seulement à cause de sa complexité gutturale, mais aussi parce que les Nains sont peu enclins à l’enseigner aux étrangers. Un humain érudit ou un historien pourra s’y essayer pour traduire les tablettes de pierre couvertes de runes – vestiges d’un royaume nain oublié – mais il lui faudra de la patience et souvent l’aide d’un conseiller nain consentant. Cette rareté en fait une langue quasi secrète hors des cercles nains : beaucoup de choses dites en Nain restent inintelligibles et donc mystérieuses pour le commun des mortels, ce qui convient très bien aux Nains lorsqu’ils veulent tenir leurs affaires à l’écart des curieux.

Le Nain s’emploie dans un contexte bien précis : celui du travail, de la famille et des traditions guerrières naines. C’est la langue qu’on entend résonner dans les ateliers enfumés, quand les maîtres-forgerons crient des instructions à leurs apprentis, ou dans les galeries minières, lorsque les mineurs coordonnent l’extraction du minerai à la lueur des torches. Autour des longues tables de banquet, dans les salles aux piliers sculptés, les toasts portés à la mémoire des ancêtres ou les chansons à boire retentissent en Nain, accompagnés du martèlement joyeux des chopes sur le bois. Sur les champs de bataille, les Nains préfèrent également aboyer leurs ordres et entonner leurs chants de guerre dans leur propre langue, y puisant fierté et courage. En revanche, pour le commerce avec l’extérieur ou les accords diplomatiques impliquant d’autres peuples, ils consentent généralement à utiliser le Commun – non par manque de fierté, mais parce qu’ils savent que **peu d’autres créatures pourraient comprendre les nuances** de leur parler ancestral. Il existe d’ailleurs chez les Nains un dicton amusé : « Parle Commun pour vendre ta bière, mais Nain pour trinquer avec tes frères. » Ceci résume bien le rôle du Commun comme langue pratique et du Nain comme langue du cœur au sein de cette culture.

L’**écriture naine** est constituée d’un alphabet runique réputé pour sa clarté et sa durabilité. Fait de lignes droites, d’angles marqués et de formes géométriques simples, chaque rune a été pensée pour être aisément gravée dans la pierre ou martelée dans le métal en fusion. Les artisans nains ornent les linteaux de porte, les frontons de temple et même leurs outils de travail d’inscriptions dans cette écriture anguleuse, consignant leurs grandes réalisations ou implorant la protection des dieux de la montagne. Un détail frappant est que les ouvrages purement littéraires sont rares en Nain : ce peuple privilégie l’oralité et l’enregistrement **lapidaire** de l’essentiel. Les livres de magie, par exemple, sont quasiment inexistants en langue naine – les rares Nains versés dans les arcanes préfèrent garder leurs secrets gravés sur des pierres runiques enchantées ou les transmettre verbalement à un disciple digne de confiance. En revanche, les archives techniques abondent : listes de filons exploités, chroniques de dynasties et de guerres de clans, manuels de métallurgie ou d’ingénierie… tous sont notés en Nain et jalousement conservés dans les bibliothèques des forteresses. Ces documents, écrits avec une précision rigoureuse, témoignent de l’étendue du savoir-faire nain et de son obsession pour le détail concret.

Du point de vue sonore, la langue naine peut paraître âpre et gutturale aux oreilles non averties. Elle est riche en consonnes roulées, en sons graves et en accentuations toniques appuyées, ce qui lui donne un **rythme martial et assuré**. Parler le Nain, c’est un peu comme faire grincer la pierre : chaque mot semble peser lourd, taillé pour durer et résonner. Pourtant, dans cette rudesse perce une musicalité profonde : chantée par un chœur dans une cathédrale souterraine, la langue déploie des harmoniques basses et puissantes qui font vibrer les murs comme les cordes d’un gigantesque instrument. Les Nains possèdent de surcroît de nombreux termes intraduisibles directement en Commun, reflétant des concepts propres à leur culture minière et métallurgique. Par exemple, ils disposent d’une dizaine de mots distincts pour différentes variétés de roche ou de métal là où un humain n’emploierait qu’un terme générique comme « pierre » ou « fer ». Cette richesse technique fait du Nain une langue **précise et sans équivoque** lorsqu’il s’agit d’aborder des sujets de la terre et du feu – la mine, la forge, la gemmologie ou la généalogie des clans.

En dehors de la société naine, le Nain demeure une curiosité linguistique plus qu’un outil pratique du quotidien. On ne scelle pas de traité de paix en langue naine, pas plus qu’on ne conte ses exploits dans une taverne humaine dans ce parler rugueux. Cependant, son **empreinte culturelle** est bel et bien présente à travers Seia. De nombreux toponymes de montagnes, de cols ou de mines proviennent du vocabulaire nain, signe que les explorateurs de ce peuple nommèrent jadis quantité de lieux dans leur langue. Lorsqu’un étranger maîtrise quelques rudiments de Nain – par exemple pour saluer respectueusement un Thane (chef de clan) dans sa langue ou pour glisser un proverbe nain lors d’un toast –, son effort est accueilli par une respectueuse surprise. C’est en quelque sorte un sésame qui lui ouvre les portes d’une franche camaraderie : les Nains apprécient qu’on honore ainsi leur parler, même s’ils rient volontiers des erreurs de prononciation commises de bonne foi. En somme, la langue naine reste le cœur battant de l’identité d’un peuple fier et tenace. Tant que dans les salles obscures et fastueuses des montagnes résonneront les voix graves s’exprimant en Nain, on saura que la culture robuste des Nains de Seia perdure indéfectiblement à travers les âges.

## ✦ Alphabet **Nain**

→ _Runes anguleuses, pensées pour la gravure dans la pierre ou le métal._

| Rune | Son | Glyphe                               |
| ---- | --- | ------------------------------------ |
| Ang  | A   | ![[Pasted image 20250523131133.png]] |
| Brok | B   | ![[Pasted image 20250523131144.png]] |
| Kar  | C   | ![[Pasted image 20250523131154.png]] |
| Dur  | D   | ![[Pasted image 20250523131205.png]] |
| Et   | E   | ![[Pasted image 20250523131231.png]] |
| Fir  | F   | ![[Pasted image 20250523131242.png]] |
| Gar  | G   | ![[Pasted image 20250523131253.png]] |
| Ha   | H   | ![[Pasted image 20250523131304.png]] |
| In   | I   | ![[Pasted image 20250523131315.png]] |
| Jor  | J   | ![[Pasted image 20250523131325.png]] |
| Khor | K   | ![[Pasted image 20250523131333.png]] |
| Lor  | L   | ![[Pasted image 20250523131344.png]] |
| Mir  | M   | ![[Pasted image 20250523131355.png]] |
| Nor  | N   | ![[Pasted image 20250523131406.png]] |
| Or   | O   | ![[Pasted image 20250523131416.png]] |
| Pur  | P   | ![[Pasted image 20250523131426.png]] |
| Qun  | Q   | ![[Pasted image 20250523131434.png]] |
| Ror  | R   | ![[Pasted image 20250523131443.png]] |
| Sur  | S   | ![[Pasted image 20250523131454.png]] |
| Thor | T   | ![[Pasted image 20250523131503.png]] |
| Uth  | U   | ![[Pasted image 20250523131513.png]] |
| Val  | V   | ![[Pasted image 20250523131525.png]] |
| Wor  | W   | ![[Pasted image 20250523131536.png]] |
| Xun  | X   | ![[Pasted image 20250523131544.png]] |
| Yor  | Y   | ![[Pasted image 20250523131553.png]] |
| Zan  | Z   | ![[Pasted image 20250523131603.png]] |

🪓 _Style :_ runes rigides, toutes gravées avec une logique géométrique stricte. Compactes.

## ✦ Nombres en **Nain**

→ _Système runique angulaire, gravé pour la robustesse et la lisibilité sur pierre._

| Son   | Chiffre | Rune Naine                           |
| ----- | ------- | ------------------------------------ |
| Grun  | 0       | ![[Pasted image 20250523131631.png]] |
| Ak    | 1       | ![[Pasted image 20250523131639.png]] |
| Dur   | 2       | ![[Pasted image 20250523131650.png]] |
| Trog  | 3       | ![[Pasted image 20250523131725.png]] |
| Karn  | 4       | ![[Pasted image 20250523131714.png]] |
| Barz  | 5       | ![[Pasted image 20250523131737.png]] |
| Zul   | 6       | ![[Pasted image 20250523131748.png]] |
| Krad  | 7       | ![[Pasted image 20250523131800.png]] |
| Tholm | 8       | ![[Pasted image 20250523131808.png]] |
| Grol  | 9       | ![[Pasted image 20250523131818.png]] |

🪓 _Chaque chiffre nain peut être gravé à l’outil dans la roche ou frappé sur du métal. Aucun arrondi, tout est anguleux, durable et lisible._