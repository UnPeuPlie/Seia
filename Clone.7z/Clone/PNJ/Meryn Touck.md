#PNJ
L'[[1. Archimage|1. Archimage]], une figure éminente de sagesse et de puissance magique, guidant l'académie d'[[Arcédia]] avec une autorité incontestée.
## Description
### Classe: 
[[Dessinateur]]
### Race:
[[Humain]]
### Académie:
[[Arcédia]]
### Rang:
[[1. Archimage]]
### Âge:
50 ans
### Taille:
1m80
### Apparence:
Assez athlétique, il a une posture droite est assurée, témoignant de son autorité et de sa maîtrise totale de la magie
### Vêtements:
Souvent vêtu d'une robe de mage richement ornée, qui drapée autour de lui, semble flotter dans les courants de magie qui l'entourent.
### Yeux:
Bleus Clair
### Cheveux:
Longs raides blancs, barbe bien entretenue et fournie
### Langues:
[[Commun]]
[[Elfique]]
[[Ancien]]