## I. Origine — _Les Larmes des Premiers Marcheurs_

> _« Ce n’est pas la foi qui fit tomber la première goutte. C’est le silence. »_

Avant les pluies, il n’y avait que la poussière et la mémoire. Le monde, craquelé par les siècles de feu et de fer, avait oublié la douceur. Les peuples étaient dispersés, les cieux muets, et les voix des sages s’étaient éteintes dans l’écho des guerres anciennes.

C’est alors qu’ils vinrent. **Les Premiers Marcheurs**.

Nul ne sait d’où ils venaient : certains disent des forêts englouties, d’autres des terres brisées du Nord. Ce que l’on sait, c’est qu’ils marchaient lentement, sans arme, sans étendard. Leur seule force : la certitude que marcher ensemble valait mieux que mourir seul.

Ils traversèrent les royaumes sans nom, offrant des mots de réconfort, du feu aux affamés, et un manteau à ceux qui grelottaient dans la nuit. Mais plus encore que leurs dons, c’est leur regard qui marqua les cœurs : un regard sans jugement, seulement de l’écoute.

Et un jour, sous un ciel où plus rien ne tombait depuis des années, ils s’agenouillèrent — non pas pour prier, mais pour écouter.

> _« Là où le monde se tait, nous nous tenons. »_

Ils restèrent ainsi un jour, deux, trois… jusqu’à ce que la pluie tombe. Une pluie fine. Une pluie tiède. Une pluie d’avant les royaumes. Elle trempa leurs visages, leurs vêtements, puis la terre elle-même. Et à cette pluie, les foules accoururent. Non pas pour se couvrir, mais pour **pleurer**.

Ce fut le début. Pas d’un ordre. Pas d’une Église. Mais d’un serment muet.

> _« Celui qui se souvient de la pluie, n’oublie jamais ceux qui l’ont appelée. »_

Ainsi naquit l’Église de la Pluie Éternelle. Non dans les mots, mais dans les actes. Non dans un temple, mais dans une offrande. Non pour gouverner, mais pour **guider**.

## II. Doctrine — _Le Cycle du Don_

> _« La pluie ne choisit pas qui elle touche. Ainsi en est-il de notre aide. »_

La doctrine de l’Église ne repose pas sur la foi en un dieu, ni sur l’obéissance à une autorité divine. Elle repose sur un constat simple, profond, irréfutable : **nul n’a grandi seul**.

Chaque membre de l’ordre est invité à méditer sur la goutte qu’il fut, et sur la pluie qu’il devient. La force, la connaissance, la paix que l’on détient ne sont pas des trophées. Ce sont des héritages. Et un héritage se transmet, ou il meurt.

La doctrine s’enseigne par cinq paroles. Elles ne sont pas des lois, mais des souffles. Leur ordre n’importe pas, car elles circulent en cercle.

---

### ✦ La Reconnaissance

> _« Il faut savoir baisser les yeux vers ceux qui vous ont élevé. »_

Ceux qui nous ont guidés sont les pierres sur lesquelles nous marchons. L’Église enseigne que tout acte de sagesse, de bonté ou de salut reçu doit être **honoré par une transmission équivalente**. Non à celui qui l’a donné, mais à un autre qui en aura besoin.

---

### ✦ L’Aide sans condescendance

> _« Celui qui aide du haut regarde déjà trop bas. »_

Aider n’est pas un droit, c’est une dette. Aucune force, aucun savoir ne justifie d’écraser. L’aide véritable se fait **à hauteur d’âme**, sans écraser, sans humilier.

---

### ✦ La Transmission silencieuse

> _« Enseigne sans te nommer. »_

Le plus grand enseignement est celui qu’on ne sait pas avoir reçu. Ainsi, les membres de l’ordre préfèrent **montrer par l’exemple**, instruire par l’attitude, corriger par la présence. Un disciple ne connaît parfois même pas le nom de celui qui l’a mis sur la voie.

---

### ✦ Le Refus du Mépris

> _« Mépriser, c’est croire que la pluie ne tombe pas sur certains. »_

Il n’est jamais permis de juger l’ignorant, le faible, ou même l’injuste. Chacun est en chemin. Le rôle du fidèle est de **devenir refuge**, pas tribunal.

---

### ✦ L’Équilibre

> _« Donne quand tu es plein. Reçois quand tu es vide. Et ne crains ni l’un ni l’autre. »_

La doctrine enseigne que tout donneur sera un jour receveur. Que tout guide se perdra un jour. Et qu’ainsi, l’équilibre est juste. **L’orgueil naît quand on oublie qu’on a été petit.**

---

**Ces cinq paroles** forment ce que l’on appelle dans l’Église : **le Cycle du Don**. Le fidèle est une goutte en perpétuel mouvement. Il doit tomber, ruisseler, nourrir. Et un jour, rejoindre la mer.

## III. Hiérarchie — _Les Quatre Figures de l’Onde_

> _« Tous les rôles sont sacrés, mais un seul est muet. »_

L’Église de la Pluie Éternelle ne connaît ni trône, ni sceptre. Elle repose sur une **structure circulaire**, où chaque rang **ne commande pas**, mais **guide en silence**. On n’élève pas quelqu’un au rang supérieur. Il s’y tient lorsque ses actes le hissent, et que son reflet dans les autres en atteste.

---

### ✦ 1. Le Héraut — _Celui qui murmure dans la brume_

> _« Il n’élève pas la voix. Et pourtant, tout s’incline. »_

Le **Héraut** n’est pas un roi, mais un écho. Il est celui que tous écoutent parce qu’il **n’a plus rien à prouver**. Choisi par un cercle de Murs anciens, il parle rarement. Lorsqu’il s’adresse à l’Église, ses mots sont transcrits comme des _Ondes de Verbe_, et deviennent loi par le poids de leur justesse.

Son symbole est une **goutte couronnée**, mais nul or, nul joyau. La couronne est souvent une simple ligne tracée en cendre.

---

### ✦ 2. Le Mur — _Celui qui soutient sans se briser_

> _« On ne sait jamais combien de vies a sauvées un mur… avant qu’il tombe. »_

Les **Murs** sont les **piliers silencieux**. Ils forment, soutiennent, écoutent. On les trouve dans les Refuges, dans les rues, parfois même dans les tribunaux où ils ne parlent que pour demander une grâce.

Un Mur ne frappe jamais. Il **empêche de tomber**. Il est le souvenir vivant de ce que fut un jour chaque fidèle : vulnérable et en recherche.

---

### ✦ 3. Le Bouclier — _Celui qui encaisse pour que d’autres marchent_

> _« Il ne frappe pas pour vaincre. Il se tient pour interdire. »_

Le **Bouclier** est celui qu’on envoie lorsque la parole n’a pas suffi. Ce n’est pas un guerrier : c’est un **rempart mobile**, formé à **protéger sans dominer**. On dit que le Bouclier ne dégaine jamais s’il peut prendre le coup à la place.

Il porte un **écu peint** d’une pluie argentée. Non pour se défendre lui-même, mais pour **absorber la violence du monde** à la place des siens.

---

### ✦ 4. La Main — _Celle qui touche, soulève, sert_

> _« Toute pierre levée le fut par une main. »_

La **Main** est le premier pas. C’est celui ou celle qui vient **pour aider, pour écouter, pour apprendre**. Tous commencent là, et bien des âmes choisissent d’y rester. Car être une main n’est pas être moins. C’est **être au plus près du geste.**

Une main qui soigne, qui nourrit, qui enseigne, qui panse. Une main qui parfois **se tend sans savoir si elle sera prise.**

---

La hiérarchie est fluide. Un fidèle peut passer d’un rôle à l’autre, selon ce que la Pluie appelle de lui. Il n’y a **ni montées, ni descentes**. Il n’y a que des positions d’équilibre, dictées par le besoin des autres.

## IV. Rituel d’Entrée — _La Veillée des Premiers Pas_

> _« On n’entre pas dans l’Église. On s’y découvre. »_

Le rituel d’entrée dans l’Église de la Pluie Éternelle ne connaît ni proclamation publique, ni baptême solennel. Il est **personnel**, **silencieux**, et **invisible à ceux qui n’écoutent pas**. Il n’est écrit nulle part, mais vécu partout.

On l’appelle : **la Veillée des Premiers Pas**.

---

### ✦ Le moment du doute

Lorsque l’âme sent que le monde est trop sec, que ses pas ne portent plus, que la force seule ne suffit plus à avancer — alors vient le moment. L’aspirant doit se rendre dans un lieu ouvert : un champ, une ruine, un toit, un passage.

Il y **attend la pluie**. Elle peut tomber en une heure, en dix jours, ou ne jamais venir. Il ne peut parler. Il ne peut appeler. Il **ne doit jamais expliquer pourquoi il est là.**

---

### ✦ L’apparition du guide

Quand la pluie survient, même fine, même invisible, **le silence devient prière**. Si un membre de l’Église — Mur, Bouclier ou même Main — est présent, et reconnaît le geste, il peut s’approcher.

Il place alors **un manteau** sur les épaules de l’attenteur, sans mot, sans question. Par ce simple geste, **l’aspirant devient une Main**. Il ne prêtera pas serment. Son silence et sa patience furent plus éloquents que n’importe quelle déclaration.

---

### ✦ L’absence de manteau

Si personne ne vient, le fidèle peut revenir. Trois fois. La quatrième, il ne doit plus essayer. Car il faut savoir **accepter de ne pas être prêt**.

> _« Tous doivent attendre. Tous ne doivent pas entrer. »_

---

### ✦ La Marque de l’Eau

Une fois reconnu, le nouveau membre trace sur son poignet gauche **un anneau à l’eau pure**. Il disparaîtra, mais **son souvenir restera**. Car nul n’oublie la pluie qui l’a reconnu.

---

Ce rituel fonde l’Église non sur l’appartenance, mais sur l’engagement silencieux. Il est le premier don : **le temps donné, l’orgueil abandonné, l’espoir rendu nu sous les cieux.**

## V. Prières — _Les Paroles qui n’implorent pas_

> _« Les dieux ont leurs fidèles. La pluie a ses silences. »_

L’Église de la Pluie Éternelle ne prie pas pour être exaucée. Elle prie pour **se souvenir**, **honorer**, **transmettre**. Chaque prière est une offrande — **non pas tournée vers le ciel, mais vers l’autre**. Les mots n’invoquent pas. Ils **rappellent ce que l’on est censé ne jamais oublier**.

Aucune prière n’est obligatoire. Toutes peuvent être dites en silence. Certaines se murmurent dans la pluie, d’autres se gravent sur les murs des refuges.

---

### ✦ Prière du Don

> _« Puisqu’on m’a tendu la main,  
> Je ne la refermerai jamais.  
> Puisqu’on m’a parlé quand j’étais silence,  
> Je deviendrai parole pour un autre.  
> Que mes pas soient portés par la gratitude,  
> Que mes forces ne soient pas pour moi seul.  
> Et qu’un jour, si je tombe,  
> Quelqu’un se souvienne de ma main tendue. »_

---

### ✦ Litanie de la Reconnaissance

> _« À ceux qui m’ont élevé, je donne mes pas.  
> À ceux qui me suivent, je donne mon ombre.  
> Et si je suis seul,  
> Que ma trace leur indique encore le chemin. »_

Cette litanie est récitée avant un long voyage, ou à la veille d’un choix difficile. Elle est aussi inscrite dans les chapelles pluvieuses — petits autels laissés à l’abandon, mais jamais détruits.

---

### ✦ L’eau du silence

Certains fidèles ne prient jamais à haute voix. À la place, ils pratiquent ce que l’on appelle **l’Eau du Silence** : ils remplissent une coupe d’eau pure, y plongent un doigt, et tracent une **goutte** sur leur cœur. Ce rituel **remplace toute parole**, et suffit à dire gratitude, pardon, engagement ou adieu.

> _« La pluie parle pour ceux qui se taisent. »_

---

### ✦ Invocation de Veille

> _« Que mes mains restent ouvertes.  
> Que mes mots ne soient ni chaînes ni murs.  
> Que mon sommeil ne m’éloigne pas des douleurs des autres.  
> Que je sois veille, même dans la nuit. »_

Récitée avant le repos, cette prière est fréquemment utilisée par les Boucliers en mission, ou les Mains en charge d’un refuge.

---

Chaque prière est un acte de don, jamais de demande. On ne prie pas pour être protégé — on prie pour **mieux protéger**.

## VI. Symbole Sacré — _La Goutte et la Main_

> _« Le symbole ne commande pas. Il rappelle. »_

Au cœur de l’Église de la Pluie Éternelle, il n’y a ni croix, ni œil, ni flamme. Il y a **une main ouverte**, **trois gouttes**, et **le souffle d’un cercle de brume**. Gravé, cousu, peint ou simplement évoqué du bout des doigts, ce symbole est **le seul visage visible de la foi invisible**.

---

### ✦ Description

- **La main** est toujours **ouverte vers le ciel**, les doigts légèrement écartés. Elle représente la **disponibilité**, la **fragilité assumée**, et la **capacité à recevoir comme à offrir**.
    
- **Les trois gouttes**, tombant sur la paume, incarnent :
    
    1. Le don reçu dans l’enfance ou l’ignorance
        
    2. Le don offert à autrui dans la maturité
        
    3. Le don oublié mais essentiel, transmis sans le savoir
        
- **Le cercle de brume** n’est jamais fermé. Il **flotte partiellement autour du tout**, marquant la **souplesse**, l’**absence de domination** et le **mouvement constant**. Il est parfois remplacé par **un anneau d’eau**, dessiné d’un seul trait, jamais parfait.
    

---

### ✦ Usage

Le symbole n’est jamais porté sur le front, ni brandi. Il se **porte près du cœur**, brodé sur l’intérieur du manteau, ou tatoué discrètement sur la clavicule gauche. On ne le montre pas, sauf quand un frère ou une sœur **perd la pluie** — autrement dit, **oublie pourquoi il a tendu la main**.

> _« Celui qui cache le signe le protège. Celui qui l’exhibe l’use. »_

---

### ✦ Gestes associés

Lorsque deux membres se reconnaissent, ils n’échangent pas de mots. Ils placent **la main droite paume vers le haut**, puis tracent **trois petits cercles** dans leur paume gauche avec l’index.

Ce geste est appelé **la Reconnaissance muette**. Il signifie :  
**« J’ai reçu. Je donne. Je me souviens. »**

---

Le symbole sacré n’est pas un drapeau. C’est un **miroir discret**, une empreinte sur l’âme. Il ne protège pas. Il **rappelle**. Et parfois, c’est tout ce qu’il faut pour ne pas s’effondrer.

## VII. Fautes et Expiation — _Ce que la pluie lave_

> _« L’Église ne punit pas. Elle attend la pluie. Et elle écoute ce que tu fais sous elle. »_

Dans l’Église de la Pluie Éternelle, il n’y a pas de juges. Il n’y a pas de geôles. Mais il existe des **fautes** — non contre une loi, mais contre l’équilibre. Et chaque faute trouble le cycle du don, l’écoulement des mémoires.

Ces fautes, dites **brisures de l’onde**, ne sont pas classées par leur gravité, mais par la **rupture de lien** qu’elles provoquent : envers les autres, envers soi, ou envers la Pluie elle-même.

---

### ✦ Brisures principales et leurs réparations

|Fautes|Description|Rite d’Expiation|
|---|---|---|
|**Refus d’aide**|Fermer la main quand on peut l’ouvrir.|**Goutte de Cendre** : marque noire sur le front, portée jusqu’à la première pluie naturelle.|
|**Mépris d’un guide**|Oublier ou dénigrer celui qui a transmis.|**Silence des Saisons** : se retirer des paroles pendant un cycle lunaire. On ne conseille plus, on écoute.|
|**Orgueil déclaré**|Utiliser ses actes pour dominer.|**Veillée Courbée** : servir sans nom ni vêtement d’ordre, à visage découvert, auprès de ceux qu’on a blessés.|
|**Aide perverse**|Offrir pour obtenir ou manipuler.|**Négation de la Main** : l’initié porte un gant noir sur la main droite, interdit de toucher autrui jusqu’au pardon sincère.|
|**Abandon du refuge**|Laisser une tâche sans passage de relais.|**Sentier du Remords** : retourner sur le lieu abandonné, y veiller seul trois jours, sans tente ni abri.|

---

> _« Il n’y a pas de faute qui ferme la pluie. Il n’y a que des cœurs trop secs pour la sentir. »_

---

### ✦ Le rôle du Mur

Les **Murs** sont les seuls à pouvoir proposer un **Rite de réparation**. Ils ne décident pas de la gravité, mais observent **si le fidèle a compris ce qu’il a brisé**.

Un Mur ne reproche jamais. Il **tend la première goutte**, puis s’éloigne. Si l’autre la boit, le lien est rétabli.

---

### ✦ L’oubli volontaire

Certains quittent l’Église sans mot. On ne les blâme pas. Leur nom est retiré des récits, mais non par haine : **pour ne pas troubler leur silence**.

> _« Mieux vaut une goutte partie qu’une goutte stagnante. »_

---

L’expiation n’est jamais spectacle. Elle est **trace**, **humilité**, **retour**. Et elle se conclut toujours par un acte sans témoin.

## VIII. Le Cycle Pluvial — _Les Mois où le silence parle_

> _« La pluie a son propre calendrier. Il commence quand tu tends la main. »_

L’Église de la Pluie Éternelle suit un **cycle symbolique**, non un calendrier civil. Elle reconnaît **trois moments majeurs dans l’année**, appelés **les Saisons de l’Âme**. Ces périodes ne suivent pas les mois solaires mais **les signes du monde** : une floraison inattendue, une pluie à contretemps, une migration étrange.

Chaque saison est associée à un **rite collectif** et à un **cheminement intérieur**. Les Refuges adaptent leurs chants, leurs couleurs, et même leur nourriture à ces cycles.

---

### ✦ I. Lune d’Argile — _La Sève qui monte_

> _« C’est le mois où l’on reconnaît ce que l’on doit transmettre. »_

- **Symbole :** main enduite d’argile
    
- **Couleurs portées :** ocre, sable
    
- **Rite associé :** **Le Semis des Promesses** : chaque fidèle plante une graine symbolique dans un sol vivant (terre, sable, mousse). Il y murmure un nom ou un souvenir qu’il doit honorer par un acte dans l’année.
    

Durant cette période, les Mains sont incitées à **rechercher un guide oublié** ou à **instruire quelqu’un sans se nommer**.

---

### ✦ II. Larmes Longues — _Le Sel dans la Paume_

> _« C’est le mois où l’on demande pardon pour ce qu’on a oublié d’aider. »_

- **Symbole :** goutte d’eau mélangée à une larme
    
- **Couleurs portées :** gris cendre, perle
    
- **Rite associé :** **Pardon de la Pluie** : chaque fidèle remplit une coupe d’eau. Il y ajoute une larme volontaire, puis la verse lentement dans un cours d’eau ou sur la pierre. Ce geste libère les fautes non dites, les absences involontaires, les dettes invisibles.
    

Les Refuges durant cette saison offrent **hébergement gratuit** à tous, et **aucune question n’est posée aux errants**.

---

### ✦ III. Nuit d’Eau — _La Veille des Silences_

> _« C’est le mois où l’on se rappelle que l’on mourra. Et que d’autres marcheront. »_

- **Symbole :** chandelle trempée, éteinte
    
- **Couleurs portées :** bleu nuit, encre
    
- **Rite associé :** **Veillée des Refuges** : chaque fidèle veille une nuit sans feu, à l’extérieur, en silence. Ce rituel rappelle la **fragilité du souffle** et la nécessité de **laisser trace utile**.
    

Les Boucliers se retirent souvent cette saison. Ils **marchent seuls** de Refuge en Refuge, observant, réparant, puis repartant sans mot.

---

Ces saisons ne sont pas fixes. **Elles sont déclenchées par les signes.** Ainsi, un Refuge peut entrer dans la Lune d’Argile en plein hiver, ou tenir la Nuit d’Eau deux fois dans la même année.

> _« La pluie ne revient jamais au même endroit.  
> Mais chaque fois qu’elle tombe, elle recommence tout. »_

## IX. Lieux Saints — _Là où l’eau a laissé trace_

> _« Ce ne sont pas les murs qui rendent un lieu sacré. C’est ce qu’on y a fait en silence. »_

L’Église de la Pluie Éternelle ne bâtit pas de cathédrales. Elle **révèle** les lieux, elle **les écoute**. Un endroit devient sacré lorsqu’il **témoigne d’un acte de guidance, d’un pardon offert, ou d’une mémoire honorée**.

Certains lieux sont connus de tous. D’autres sont **cachés**, ou n’apparaissent qu’à ceux qui savent lire les signes de l’eau.

---

### ✦ La Source d’Irhal — _Là où tomba la première goutte_

Située dans une clairière brumeuse que les cartes refusent de fixer, la Source d’Irhal est **le sanctuaire fondateur**. On y trouve une dalle de pierre creuse, dans laquelle l’eau suinte lentement — même en plein été.

> _« Ce lieu n’est pas protégé. Il est offert. Comme doit l’être toute vérité. »_

Chaque Héraut y passe **trois jours en silence** avant sa reconnaissance officielle. Aucun mot n’en est jamais rapporté.

---

### ✦ Le Refuge des Brumes — _Le bastion du silence partagé_

Construit dans une ancienne tour d'observation en haut de la chaîne de Keshar, ce lieu accueille **ceux qui ne trouvent plus les mots**. Les murs sont tapissés de bandeaux de tissu où les fidèles écrivent un souvenir, une douleur ou un pardon non adressé.

Les Boucliers s’y rendent parfois pour **confesser ce qu’ils n’osent dire**. Et les Gouttelots en formation y passent leur première Nuit d’Eau.

---

### ✦ Le Hall des Voix Absentes — _La crypte des Hérauts endormis_

Un lieu troglodyte, profond, gardé par une seule Main. On y dépose les manteaux et objets des Hérauts disparus — même sans certitude de leur mort. Les objets sont déposés dans le sable. Jamais enterrés, jamais nommés.

> _« Le nom est le dernier poids. Ici, ils ne portent plus rien. »_

Un fidèle peut y entrer une fois dans sa vie. Il n’en sortira jamais le même.

---

### ✦ Les Chapelles Pluvieuses — _Autels sans murs_

Souvent improvisées : un rocher lisse, une dalle abandonnée, un arbre creux. Là où quelqu’un a **aidé sans témoin**, ou **pardonné sans retour**. Des pierres y sont parfois alignées en spirale. Chaque pierre représente un silence gardé.

Les fidèles les restaurent, jamais ne les déplacent.

---

> _« Chaque lieu peut devenir saint si la main qui y agit ne réclame rien. »_

## X. Objets Sacrés — _Ce que l’on porte, ce que l’on promet_

> _« Un objet sacré n’est pas ce qu’il fait. C’est ce qu’il retient. »_

L’Église de la Pluie Éternelle ne vénère pas les objets. Elle **les reconnaît**. Chacun d’eux est **le témoignage silencieux d’un passage, d’un choix, d’un engagement**. On ne reçoit jamais un objet sacré sans être prêt à le perdre. Car tous peuvent être rendus à la pluie si l’âme qui les porte se dessèche.

---

### ✦ Bâton de Brume — _Soutenir sans frapper_

Remis aux **Murs** lors d’un rite de silence, ce bâton est taillé dans un bois ramassé par le porteur lui-même. Il ne porte **aucune marque** visible, mais l’intérieur de sa hampe contient une **tige de fer froid** : elle vibre légèrement sous la pluie.

Le Bâton de Brume ne s’utilise pas pour se battre, mais pour **tracer, soutenir, marquer les limites entre le conflit et la paix**.

> _« Le vrai Mur ne sépare pas. Il soutient deux côtés. »_

---

### ✦ Anneau d’Argile — _La trace du premier choix_

Chaque **Main** en reçoit un lors de son premier engagement. Modelé par ses propres doigts, puis durci au feu ou au soleil, il est souvent irrégulier. Cette **imperfection est sacrée** : elle rappelle que le don vient d’une main humaine, et non divine.

Si un fidèle quitte l’Église, il enterre l’anneau sous la pluie. Et s’il revient un jour, il **ne reprend pas l’ancien. Il en façonne un autre.**

---

### ✦ Tablier de Pluie — _Servir même dans le feu_

Porté par les **Boucliers**, ce vêtement est tissé dans une toile brute, teintée naturellement avec des cendres et de l’eau stagnante. Résistant, imperméable, lourd, il est conçu pour **absorber l’impact**, **tenir sous la tempête**, **s’user au combat sans jamais sembler menaçant**.

Le tablier n’est jamais lavé. Chaque tache, chaque entaille, **raconte une défense silencieuse**.

---

### ✦ Calice de Goutte — _Offrir sans attendre_

Présent dans certains Refuges, ce calice est laissé à l’entrée. Ceux qui en ont besoin peuvent y boire de l’eau. Ceux qui passent peuvent y verser la leur. Il est symbole de **l’échange invisible**. Si le calice est renversé, cela signifie qu’un conflit a eu lieu — mais jamais raconté.

> _« On ne boit pas la paix. On la verse. »_

---

### ✦ Fil de Veille — _Ne pas dormir seul_

Dans certaines missions, une Main tisse un fil entre sa paume et celle de celui ou celle qu’elle veille. Tant que le fil n’est pas rompu, le lien demeure, même dans le sommeil. Si le fil casse, on ne cherche pas qui l’a tiré : on **recommence**, plus doucement.

---

Chaque objet sacré est un **geste figé**, une **mémoire offerte à la matière**. Et lorsque la pluie tombe dessus, elle ne les abîme pas — **elle les lit.**

## XI. Le Mythe de la Première Pluie — _Avant le Geste, le Silence_

> _« Nul ne se souvient de la première prière.  
> Mais tous se souviennent de la première goutte. »_

Avant les hommes, avant les mots, avant même que le monde ne sache qu’il manquait quelque chose, le ciel était fermé. **Les saisons tournaient sans odeur, la terre craquait sous le poids des promesses non tenues.** Il n’y avait pas encore de dieux. Seulement des pierres, et la mémoire de ce qui avait été.

---

### ✦ La Terre Muette

On raconte qu’au commencement, la Terre elle-même avait oublié comment parler. Trop de cris. Trop de feu. Trop de conquêtes. Alors, elle se mura dans le silence. Les hommes bâtirent des royaumes sur ce silence. Ils y creusèrent leurs tombes, y gravèrent leurs lois. Mais **rien ne poussait plus**.

> _« Ils avaient des mots, mais pas de voix. Des lois, mais pas de lien. »_

---

### ✦ Le Cercle des Cinq

Cinq âmes se rencontrèrent dans une vallée nue. Nul ne sait d’où elles venaient, ni même si elles étaient humaines. Elles ne parlèrent pas. **Elles s’assirent.** L’une déposa un fruit, l’autre un vêtement, la troisième un souvenir écrit, la quatrième un outil brisé, la cinquième : **rien**. Elle tendit simplement la main, vide.

Et le ciel l’aperçut.

---

### ✦ La Goutte sans Orage

La pluie ne tomba pas en torrent. Elle ne tonna pas. Elle **glissa. Une seule goutte**, sur la paume nue de la cinquième. Les autres la virent et **pleurèrent sans savoir pourquoi.**

Cette goutte fut la première prière. Pas celle qu’on élève. Celle qu’on reçoit. Et elle **ne demandait rien**.

---

### ✦ Le Pacte Invisible

Depuis ce jour, on dit que la pluie ne tombe **que lorsqu’elle voit une main ouverte**. Elle n’obéit pas. Elle répond. Elle n’oblige pas. Elle **accompagne**.

Ce mythe n’est jamais raconté de la même manière deux fois. Il n’est pas consigné. Il **s’écoute à la lueur d’un feu mourant**, ou sous l’auvent d’un refuge.

> _« Le ciel se souvient. Et parfois, il répond. »_

## XII. Chant Rituel — _Paroles sous la Pluie_

> _« Ce n’est pas un chant pour être entendu. C’est un souffle pour ne pas s’éteindre. »_

Ce chant n’a pas de mélodie figée. Il s’adapte au rythme de la pluie, au frisson des feuilles, à la respiration d’un enfant qu’on console. Il se chante seul ou à plusieurs. Il ne cherche pas l’harmonie : **il cherche l’intention.**

Il est offert lors :

- Des veillées de deuil
    
- Des veilles avant mission
    
- Des retraites silencieuses
    
- Des pardons demandés ou non rendus
    

---

### ✦ Paroles sous la Pluie

> _Ne dis rien.  
> Tu n’es pas seul.  
> D’autres ont marché avant toi,  
> D’autres suivront tes traces._

> _Tu n’es pas perdu.  
> La pluie connaît ton nom.  
> Elle ne t’appelle pas,  
> Elle t’attend._

> _Tends ta main.  
> Oublie ton orgueil.  
> Rappelle-toi ceux qui t’ont levé,  
> Même si tu as oublié leur visage._

> _Et quand tes genoux plieront,  
> Que ton souffle sera court,  
> Ne cherche pas le cri.  
> Écoute._

> _C’est elle qui te répondra._

---

### ✦ Gestes associés

Lorsqu’il est chanté à plusieurs, les membres se tiennent en cercle, paume gauche ouverte vers le ciel, paume droite contre leur propre cœur. À la dernière strophe, chacun ferme les yeux.

Un Bouclier peut frapper le sol avec son bâton une seule fois : cela **scelle le souvenir** pour toujours dans le cercle.

---

### ✦ Usage particulier

Les Gouttelots apprennent ce chant sans jamais l’écrire. Leur première mission est de **le transmettre à quelqu’un qui n’appartient pas à l’Église**, sans jamais se nommer.

> _« Si ce chant te touche, tu portes déjà la pluie. »_

## XIII. Enseignements du Héraut — _Ce que l’on n’écrit qu’après l’avoir vécu_

> _« Le Héraut ne donne pas de lois. Il parle en ondée. Il murmure ce que chacun doit entendre. »_

Les Hérauts, dans leur silence légendaire, ne prononcent que peu de paroles au cours de leur vie. Mais celles qui sont prononcées sont **mémorisées par les Murs**, transmises oralement, **jamais écrites sans nécessité**.

Ceux qui les entendent ne les oublient pas. Et parfois, une seule phrase **peut guider une vie entière**.

---

### ✦ Paroles reconnues

> _« Si tu tends la main pour qu’on te voie, tu ne portes pas la pluie. Tu portes ton nom. »_

> _« Ne cherche pas celui qui ne t’écoute pas. Écoute celui qui ne te cherche plus. »_

> _« Tu ne protégeras jamais quelqu’un si tu veux qu’il s’en souvienne. »_

> _« Un mot dit à voix haute doit pouvoir être entendu sous la pluie. Sinon, il ne vaut rien. »_

> _« Chaque fois que tu aides, souviens-toi de celui qui n’a pas pu t’aider. »_

---

### ✦ Maximes silencieuses

Ces phrases sont parfois tracées dans les Refuges, gravées dans les dalles, murmurées entre Boucliers ou Gouttelots. On les appelle les **Ombres du Héraut**. Elles ne sont pas attribuées formellement, mais reconnues comme « vraies ».

- _« On ne devient pas guide. On s’efface jusqu’à ce que le silence soit suivi. »_
    
- _« Le geste juste ne laisse pas de dette. »_
    
- _« Si tu parles pendant que l’autre pleure, ce n’est pas lui que tu consoles. »_
    

---

### ✦ Le dernier enseignement

Chaque Héraut, à la fin de sa vie, prononce une dernière phrase. Elle est transmise à la pierre de son manteau, gravée en minuscule, face contre terre. Personne ne peut la lire, sauf en soulevant la pierre.

Mais nul ne le fait. Car ce savoir est **offert à la terre**, non aux hommes.

> _« Si quelqu’un doit la lire, c’est que la pluie ne suffit plus. »_

## XIV. Règles de conduite hors sanctuaire — _La Pluie en Pas Silencieux_

> _« Le monde ne sait pas que tu es là. Et pourtant, il doit se souvenir de ton passage. »_

Les membres de l’Église de la Pluie Éternelle ne portent ni bannière ni appel. Ils vivent parmi les autres, souvent sans se déclarer. Pourtant, **leur conduite les distingue**, non par éclat, mais par constance. Chaque geste, chaque parole, chaque silence porte **la marque invisible de l’Onde**.

Ceux qui marchent sous la Pluie obéissent non à une loi, mais à une mémoire partagée.

---

### ✦ Règles fondamentales

#### 1. **Tends la main, même si elle est vide.**

Ne présume jamais de ce que l’autre attend. Aide **sans condition préalable**, sans engagement demandé.

#### 2. **Ne parle pas en premier si l’autre est en souffrance.**

Laisse le silence ouvrir la voie. Parfois, la seule écoute **suffit à apaiser plus qu’une centaine de mots**.

#### 3. **Ne dis jamais que tu fais partie de l’Église, sauf si cela sauve une vie.**

Ton appartenance ne doit jamais être utilisée pour **convaincre, imposer ou séduire**. Elle est un lien, pas un titre.

#### 4. **Protège sans humilier.**

Si tu dois intervenir dans un conflit, fais-le **sans éteindre celui que tu protèges**. Offre ton corps avant tes mots.

#### 5. **Partage sans expliquer.**

Donne ce que tu peux sans chercher à en tirer gratitude ou reconnaissance. **Fuis le sermon, offre le silence.**

---

### ✦ Signes discrets de reconnaissance

- **Trois traits tracés à la base d’un bol** : indique qu’un repas est libre.
    
- **Un caillou posé sur un banc humide** : invitation à partager sans parole.
    
- **Un cercle d’eau effacé autour d’une porte** : une veille silencieuse a eu lieu ici.
    

> _« Ce que tu laisses doit pouvoir être effacé par la pluie. Si ça ne s’efface pas, ce n’est pas un acte juste. »_

---

### ✦ Cas particuliers

- **Face à l’injustice flagrante** : le Bouclier peut se lever. Il **n’explique pas**. Il agit. Puis il s’efface.
    
- **Face à un appel d’aide public** : toute Main peut répondre, à condition de **ne pas imposer son nom**.
    
- **Face à la richesse** : refuse tout paiement. Accepte les dons uniquement **si tu n’en dis rien à personne.**
    

---

Les fidèles ne cherchent pas à être bons. Ils cherchent à **être utiles, puis à s’effacer.** Et si quelqu’un demande un jour : _« Qui était-ce ? »_, alors l’Église aura bien agi.

## XV. Les Gouttelots — _Ceux qui portent la Pluie avant de la comprendre_

> _« On ne devient pas enfant de la Pluie. On y est abandonné, puis relevé. »_

Les **Gouttelots** sont les enfants confiés à l’Église, souvent orphelins, perdus, ou tout simplement **trop silencieux pour le monde qui les entoure.** Leur nom vient du mot ancien _Guttariel_ : _ceux qui ne pleurent pas encore_.

Chaque Gouttelot est **élevé dans un Refuge**, sous la garde d’un Mur ou d’un Bouclier. Ils ne reçoivent pas d’éducation imposée : **ils imitent, ils écoutent, ils sentent.** On ne leur demande pas d’obéir, mais d’observer.

---

### ✦ Le Rite du Premier Silence

À l’âge de 7 ans, chaque Gouttelot effectue une **Veille de Lune** : une nuit passée seul dans une pièce nue, avec seulement un récipient d’eau et une bougie. Au lever du jour, il doit **dessiner un seul symbole dans l’eau**.

Ce symbole n’est pas interprété. Il est **archivé**, et devient **le glyphe intime du Gouttelot**.

> _« Ce que l’enfant trace, l’adulte l’oubliera peut-être. Mais l’eau s’en souviendra. »_

---

### ✦ Le Choix

À l’âge de 12 ans, chaque Gouttelot est amené à la **Pierre du Choix**, une dalle ancienne posée au cœur de la clairière d’un Refuge majeur. Il porte dans sa paume **une goutte d’argile**, modelée par lui-même.

Sans parole, il **pose cette goutte sur un des quatre coins de la pierre**, chacun représentant une voie :

- Nord : **Main**
    
- Est : **Bouclier**
    
- Sud : **Mur**
    
- Ouest : **Silence** (le chemin de ceux qui quittent l’Église)
    

> _« On ne leur dit jamais quoi choisir. La pluie regarde. Et parfois, elle guide. »_

---

### ✦ Ceux qui choisissent le Silence

Certains enfants, au moment du rite, **gardent l’argile dans leur main** et ne la posent jamais. On ne leur pose aucune question. On les raccompagne, et **on les laisse marcher.**

Beaucoup d’entre eux, des années plus tard, **reviennent sous la pluie**, paume ouverte, sans mot.

---

### ✦ L’enseignement par l’exemple

Les Gouttelots ne récitent pas de textes. Ils **nettoient, veillent, écoutent**. Ils aident les blessés, préparent les repas, escortent les muets. Ils apprennent la doctrine **par les gestes qu’on leur fait**.

Un Gouttelot qui pose la main sur l’épaule d’un inconnu en détresse **enseigne déjà la première vérité.**

---

> _« L’eau coule mieux dans les mains des enfants. Elle y trouve encore la forme du monde. »_

## XVI. Missions des Murs et des Boucliers — _Les Deux Rives de l’Onde_

> _« Le Mur écoute. Le Bouclier encaisse. Mais tous deux s’effacent quand la paix revient. »_

Les **Murs** et les **Boucliers** ne forment pas une autorité dans l’Église. Ce sont **des gardiens de l’équilibre**, des **passeurs de mémoire**, des **protecteurs sans domination**. Ils n’interviennent jamais par orgueil, mais **par nécessité**, et se retirent dès que la pluie peut reprendre sa chute sans eux.

Leur formation n’est pas un enseignement. C’est une épreuve d’années entières, de services répétés, **de silences gardés au prix de soi.**

---

### ✦ Murs — _Ceux qui soutiennent sans imposer_

Le Mur est une **archive vivante**. Il **observe**, **transmet**, **rappelle**. C’est vers lui que les Gouttelots se tournent quand un mot leur échappe, que les Mains vont quand elles doutent, que même les Hérauts consultent parfois dans l’ombre.

#### Missions principales :

- **Tenir un Refuge**
    
- **Superviser les Rites de Passage**
    
- **Consigner les Enseignements entendus**
    
- **Rappeler la doctrine lorsqu’un membre s’en éloigne — sans jamais le condamner**
    

> _« Quand le Mur parle, c’est que le monde s’effrite. »_

---

### ✦ Boucliers — _Ceux qui se dressent quand la parole ne suffit plus_

Le Bouclier n’est pas un soldat. Il est **la fin de la parole, pas le début de la guerre**. Il encaisse, protège, isole la menace **sans frapper plus que nécessaire**. Sa présence suffit souvent à apaiser une tension.

Il dort peu, parle peu, mais **sent quand une veine du monde va se rompre.**

#### Missions principales :

- **Protéger un Refuge en période de trouble**
    
- **Accompagner les Rites de Pardon risqués**
    
- **Intervenir dans un conflit extérieur lorsque les fidèles sont impliqués**
    
- **Tenir les Veillées de Frontière : surveiller un seuil invisible entre deux mondes en tension**
    

> _« Il est le tonnerre contenu, la pluie contenue. Quand il cède, ce n’est jamais à la légère. »_

---

### ✦ Coordination

Murs et Boucliers se **reconnaissent d’un regard**, mais n’ont aucun droit l’un sur l’autre. Lorsqu’ils doivent agir ensemble, ils s’accordent sur un **silence partagé** : ils marchent côte à côte, sans mot, jusqu’à ce que la nécessité les sépare.

---

### ✦ Rites communs

Une fois par cycle pluvial, chaque Mur et Bouclier retourne à la **Source d’Irhal**, dépose un galet dans l’eau et **prononce le nom de celui qu’il n’a pas pu sauver**. Puis il part, **sans récupérer le galet.**

---

> _« Nul ne protège sans faillir. Mais tant que l’eau coule, il est encore temps. »_

## XVII. Les Mains — _Les Gouttes qui touchent le monde_

> _« Ce que fait la Main, la pluie le reconnaît. »_

Les **Mains** sont les premières figures visibles de l’Église de la Pluie Éternelle. Ce sont elles que l’on croise sur les chemins, dans les Refuges, dans les villes, **partout où un silence bienveillant peut faire œuvre.**

Mais être une Main n’est pas un rang inférieur. C’est **un choix perpétuel** de rester au contact du monde, **sans jugement, sans mission guerrière, sans orgueil**. Elles ne prétendent pas guider : **elles accompagnent.**

---

### ✦ Fonction

- **Écouter.**
    
- **Accompagner.**
    
- **Apaiser sans interférer.**
    
- **Toucher sans posséder.**
    
- **Apprendre encore, même après des années.**
    

> _« Une Main qui ne doute plus ne porte plus que son propre poids. »_

---

### ✦ Vie quotidienne

Les Mains portent un **manteau de laine grossière**, souvent de couleur cendre ou argile. À l’intérieur, brodé discrètement, se trouve **leur glyphe personnel** : un souvenir ou une promesse. Elles ne le montrent jamais, sauf en cas d’urgence morale.

Elles voyagent souvent par paires. L’une parle peu, l’autre écoute plus encore. Lorsqu’un enfant les suit sans mot, elles ne le repoussent pas — **elles le laissent marcher** jusqu’à ce que lui-même s’arrête.

---

### ✦ Rites propres

- **Le Tissage du Lien** : une Main s’assied aux côtés d’un inconnu et tisse, avec de simples brins, un cercle ouvert. Si l’autre le referme, **l’échange commence**.
    
- **La Goutte donnée** : lors d’un départ, la Main laisse toujours une petite perle d’eau dans un récipient, même s’il est vide. **C’est un signe : “quelqu’un est passé par ici, sans rien attendre.”**
    

---

### ✦ Proverbes de Mains

- _« Ne tends pas ta main vers celui qui se noie. Descends dans l’eau. »_
    
- _« Ne parle pas au nom de l’Église. Laisse l’Église parler par toi. »_
    
- _« Si tu veux faire le bien, commence par ne pas interrompre la douleur. »_
    

---

Une Main peut le rester toute sa vie. Certaines le choisissent même après avoir été Mur ou Bouclier. Car parfois, il ne reste plus rien à transmettre, ni à protéger, **sauf le geste nu de tendre la main.**

## XVIII. Les Refuges — _Les Pluies qui n’interrogent pas_

> _« Un Refuge ne demande rien. Et pourtant, il répond à tout. »_

Les **Refuges** de l’Église de la Pluie Éternelle ne sont pas des bâtiments désignés ou sanctuarisés. Ce sont **des lieux rendus sacrés par la constance de l’accueil, la discrétion du soin, et la certitude qu’ici, on ne sera jamais jugé.**

On les trouve au détour d’une ruelle, à flanc de falaise, sous une arche végétale, ou dans une maison sans nom. Mais tous partagent les mêmes signes, les mêmes silences, les mêmes gestes.

---

### ✦ Règles d’un Refuge

1. **Nul n’est interrogé à l’entrée.** Ni nom, ni origine, ni confession, ni passé ne sont demandés.
    
2. **La porte est ouverte, ou entrouverte.** Si elle est close, c’est qu’il n’y a plus de paix à offrir ce jour.
    
3. **L’eau y est disponible.** Toujours. Même peu. Même tiède.
    
4. **Un lieu de repos est offert.** Une paillasse, une pierre plate, une couverture. Le confort n’est pas garanti, mais la paix, oui.
    

> _« Le Refuge n’est pas un luxe. C’est une parenthèse entre deux douleurs. »_

---

### ✦ Les Gardiens du Seuil

Chaque Refuge est maintenu par un **Mur**, un **Bouclier**, ou une **Main ancienne**. Ils ne gouvernent pas. Ils **gardent la cadence de l’eau**, veillent à ce que les gestes soient justes, que les silences ne deviennent pas des murs.

Ils ne parlent qu’aux enfants. Et aux mourants.

---

### ✦ Signe de reconnaissance

Un petit galet noir, placé près de la porte. Lissé par le temps. Si ce galet est entouré d’un cercle de cendre, cela signifie : **danger extérieur, refuge fermé temporairement.**

---

### ✦ Fonction rituelle

Lors des **Veillées d’Eau**, les Refuges s’éteignent : aucune lumière, aucun chant. Les fidèles s’y réunissent en silence, assis les uns contre les autres, **écoutant la pluie ou l’absence de pluie**. Cette nuit-là, personne ne dort. Personne ne parle.

> _« Même sans mot, même sans feu, la chaleur passe. »_

---

### ✦ Carte invisible

Il n’existe pas de carte officielle des Refuges. Mais chaque fidèle sait reconnaître un **pan de mur à l’ombre douce**, une **fenêtre qui s’ouvre vers l’intérieur**, une **pierre au grain trop lisse**.

Et parfois, un inconnu pose la main sur l’épaule, sourit, et dit simplement :  
_« Là-bas, il y a de l’eau. »_

## XIX. Appendice Symbolique — _Ce que l’on comprend sans qu’on le dise_

> _« Le geste est plus ancien que la langue. Il ne ment pas. Il se plante dans la chair, et pousse en mémoire. »_

Dans l’Église de la Pluie Éternelle, les signes sont **plus puissants que les déclarations**. Un geste bien fait, un glyphe tracé sans témoin, une marque déposée dans la poussière : tous parlent **plus que mille sermons.**

Ils sont utilisés pour **communiquer entre fidèles**, pour **consacrer un lieu**, ou simplement pour **se souvenir de ce que l’on est.**

---

### ✦ Gestes Rituels

- **La Paume Haute**  
    Bras levé, paume ouverte vers le ciel. Signe de service et d’offrande. Utilisé pour saluer sans domination.
    
- **La Paume Inversée**  
    Main tendue vers le sol, doigts écartés. Accepte une charge ou un serment. Souvent vu lors du passage au rang de Bouclier.
    
- **Le Cercle d’Index**  
    Dessiner un cercle sur son torse avec l’index droit. Signe de pardon demandé ou donné.
    
- **Les Trois Touches**  
    Taper doucement trois fois la poitrine, là où l’eau touche. Signifie : « je me souviens, je transmets, je m’efface. »
    

---

### ✦ Glyphes Majeurs

- **Rune de la Goutte**  
    Une ligne verticale brisée à sa base. Symbole du premier enseignement : on ne tombe pas, on descend pour nourrir.
    
- **Rune du Mur**  
    Trois traits horizontaux, surmontés d’un seul vertical. Symbole de protection silencieuse et de soutien sans pression.
    
- **Rune du Souffle**  
    Spirale ascendante ouverte. Marque le commencement d’un récit ou d’une mission.
    
- **Rune du Silence**  
    Deux barres parallèles croisées d’une diagonale. Gravée à l’entrée des Refuges ou sur les tombes anonymes.
    

---

### ✦ Marques de Passage

- **Trace d’Argile**  
    Forme unique déposée par les Gouttelots lors du Rite du Choix. Non modifiable, elle devient leur sceau personnel.
    
- **Goutte de Cendre**  
    Petite marque noire portée sur le front en cas d’expiation. Ne s’efface qu’à la première pluie naturelle.
    
- **Anneau de Brume**  
    Cercle peint à l’eau sur la main droite. Dure jusqu’à l’aube. Utilisé lors des veillées de pardon silencieux.
    
- **Ligne d’Eau**  
    Tracée au sol ou sur un objet avec un doigt mouillé. Indique : « j’ai été ici, sans bruit. »
    

---

> _« Un symbole n’est pas un mot figé. Il est un écho que la pluie reconnaît. »_

## XX. Bénédiction Finale — _Que la pluie t’accompagne_

> _« Ce n’est pas une fin. C’est un écho doux, offert au pas suivant. »_

La bénédiction finale est prononcée lors des départs importants :

- Lorsqu’un fidèle quitte un Refuge pour toujours
    
- Lorsqu’un Gouttelot devient Main
    
- Lors d’un dernier souffle
    
- Ou parfois, simplement… lorsque le silence appelle à clore
    

Elle n’est jamais criée. Elle est **murmurée à l’oreille**, ou **écrite sur la pierre**. Et lorsque personne ne peut la prononcer, **la pluie elle-même s’en charge.**

---

> _« Que la pluie t’accompagne,  
> Qu’elle lave tes fautes et féconde tes pas.  
> Qu’elle parle pour toi quand tu n’as plus de voix.  
> Qu’elle pleure quand tu ne sais plus pleurer.
> 
> Que ton ombre serve d’abri,  
> Que ton silence devienne refuge.  
> Que tes gestes parlent plus que ton nom.  
> Que ta mémoire devienne semence.
> 
> Sois la goutte qui apaise,  
> Sois la main qui protège,  
> Sois le murmure qui guide.
> 
> Et lorsque viendra ton dernier souffle,  
> Que la pluie t’accueille comme l’un des siens.  
> Et qu’elle t’efface, doucement,  
> Pour que d’autres puissent marcher. »_

---

Le _Livre des Ondes_ se ferme sur ces mots. Mais la pluie, elle, continue de tomber.